const mongoose = require('mongoose');

const MONGO_URL = "mongodb+srv://wiw_db:wiwbackshot69@clusterme.qmify.mongodb.net/contest_tracker?retryWrites=true&w=majority"; // Replace with your actual MongoDB URL

const connectDB = async () => {
    try {
        await mongoose.connect(MONGO_URL, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB connected successfully');
    } catch (error) {
        console.error('MongoDB connection failed:', error.message);
        process.exit(1); // Exit process with failure
    }
};

module.exports = connectDB;
